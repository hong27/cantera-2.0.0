#include <stdio.h>

void printstring_(char* s) {
    printf("%s",s);
}
