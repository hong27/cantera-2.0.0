Convenience Functions
=====================

.. autofunction:: Cantera.gases.Air
.. autofunction:: Cantera.gases.Argon
.. autofunction:: Cantera.gases.GRI30
