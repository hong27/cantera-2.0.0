Chemical Kinetics
=================

.. autoclass:: Cantera.Kinetics.Kinetics
