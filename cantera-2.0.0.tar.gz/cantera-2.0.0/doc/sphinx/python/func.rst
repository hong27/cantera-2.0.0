Func Module
===========

.. py:currentmodule:: Func

Quick links:
   * :class:`Polynomial`
   * :class:`Gaussian`
   * :class:`Fourier`
   * :class:`Arrhenius`

.. automodule:: Cantera.Func
   :member-order: bysource
   :no-show-inheritance:
