Error Handling
==============

.. autofunction:: Cantera.getCanteraError

.. autoexception:: Cantera.exceptions.CanteraError
.. autoexception:: Cantera.exceptions.OptionError
