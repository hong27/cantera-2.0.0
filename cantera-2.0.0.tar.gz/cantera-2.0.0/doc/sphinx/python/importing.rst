Importing Phase Objects
=======================

.. autofunction:: Cantera.importPhase
.. autofunction:: Cantera.importPhases
.. autofunction:: Cantera.importEdge
.. autofunction:: Cantera.importInterface
.. autofunction:: Cantera.IdealGasMix
