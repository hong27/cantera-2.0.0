Thermodyamic Properties
=======================

These classes are used to describe the thermodynamic state of a system.

.. autoclass:: Cantera.Phase.Phase
.. autoclass:: Cantera.ThermoPhase.ThermoPhase
.. autoclass:: Cantera.SurfacePhase.EdgePhase
.. autoclass:: Cantera.SurfacePhase.SurfacePhase
