.. _scons-config:

*******************
Configuring Cantera
*******************

This document lists the options available for compiling Cantera with SCons.

These options may be seen by running the command::

    scons help

from the command prompt.

.. literalinclude:: scons-options.txt
